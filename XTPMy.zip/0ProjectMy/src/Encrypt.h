
#pragma once


void Encrypt(const char * src, const char * dst);
void Decrypt(const char * src, const char * dst);
