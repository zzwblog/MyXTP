#ifndef _XHOST_MD5_H_
#define _XHOST_MD5_H_

void calc_md5(const char* intput, int bytes, char* output);

#endif // !_XHOST_MD5_H_

